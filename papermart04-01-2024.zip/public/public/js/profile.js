
$(function() {
    setTimeout(function() {
        $('#error').remove();
    }, 2000);
});