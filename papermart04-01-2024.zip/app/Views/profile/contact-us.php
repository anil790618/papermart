

<div class="container-fluid">
	
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title m-2">Contact Us</h4>
                   
                </div>
                <div class="card-body">

                 <h3 class="text-center"> <?=$userData['user_name']?></h3>
                 <h4 class="text-center"> <?=$userData['phone_number']?></h4>
                   
                </div>
            </div>
        </div>
    </div>
</div>

