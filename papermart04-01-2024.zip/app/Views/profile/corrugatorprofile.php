 <h4>Work profile For End User Registration</h4>
                    <div class="form-row">
                         
                        <div class="form-group mb-0  col-md-4">
                            <label> Qualities used</label><span class="text-danger">*</span><br>

                            <input type="checkbox"  name="type_of_waste[]" value="Kraft Paper" >  Kraft Paper            
                           
                            <input type="checkbox"  name="type_of_waste[]" value="Duplex Paper" >  Duplex Paper  
                        </div>
                        <div class="col-md-12">
                            <div class="form-row">
                                <div class="form-group mt-2  col-md-2">
                                    <h5> Kraft paper Quality</h5>
                                </div>
                                <div class="form-group mb-0  col-md-2"><label>BF </label><input type="text" class="form-control " name="bf" tag="1" > <span class="text-danger size-7 e_bf"></span> </div>

                                <div class="form-group mb-0  col-md-2"><label>GSM </label><input type="text" class="form-control " name="gsm" tag="1" > <span class="text-danger size-7 e_gsm"></span> </div>

                                <div class="form-group mb-0  col-md-2"><label>Type</label><input type="text" class="form-control " name="type" tag="1" > <span class="text-danger size-7 e_type"></span> </div>

                                <div class="form-group mb-0  col-md-2"><label>Shade</label><input type="text" class="form-control " name="kshade" tag="1" > <span class="text-danger size-7 e_size"></span> </div>

                                <div class="form-group mb-0  col-md-2"><label>Monthly Consumption</label><input type="text" class="form-control " name="monthly_consumption" tag="1" > <span class="text-danger size-7 e_size"></span> </div>
                            </div>
                        </div>

                        <div class="col-md-12">
                            <div class="form-row">
                                <div class="form-group mt-2  col-md-2">
                                    <h5> Duplex paper Quality</h5>
                                </div>

                                 <div class="form-group mb-0  col-md-2"><label>GSM </label><input type="text" class="form-control " name="gsm" tag="1" > <span class="text-danger size-7 e_gsm"></span> </div>

                                <div class="form-group mb-0  col-md-2"><label>LWC / HWC </label><input type="text" class="form-control " name="gsm" tag="1" > <span class="text-danger size-7 e_gsm"></span> </div>

                                <div class="form-group mb-0  col-md-2"><label>Type</label><input type="text" class="form-control " name="type" tag="1" > <span class="text-danger size-7 e_type"></span> </div>

                                <div class="form-group mb-0  col-md-2"><label>Shade</label><input type="text" class="form-control " name="psize" tag="1" > <span class="text-danger size-7 e_size"></span> </div>
                            </div>
                        </div>
                        <div class="form-group mb-0  col-md-4">
                            <label>Do you use lab testing services for boxes?</label><span class="text-danger">*</span><br>
                            <input type="radio" class=" " name="labservice"   value="1"> Yes
                            <input type="radio" class=" " name="labservice"   value="0"> No
                            <span class="text-danger size-7 e_qty"></span>
                         </div>
                         <div class="form-group mb-0  col-md-4">
                            <label>How often  lab testing services for boxes is done?</label><br>
                           <input type="text" class="form-control " name="frequencylabservice"  >
                            <span class="text-danger size-7 e_qty"></span>
                         </div>
                         <div class="form-group mb-0  col-md-4">
                            <label>Normal Working Hours</label><span class="text-danger">*</span>
                            <input type="text" class="form-control " name="machine_no"  >
                            <span class="text-danger size-7 e_qty"></span>
                        </div>
                         <div class="form-group mb-0  col-md-4">
                            <label>How often you require part timer or other staff</label><span class="text-danger">*</span>
                            <input type="text" class="form-control " name="parttimer"  >
                            <span class="text-danger size-7 e_qty"></span>
                        </div>
                        <div class="form-group mb-0 col-md-4">
                                <label>Production Capacity</label><span class="text-danger">*</span>
                                 <input type="text" class="form-control " name="producttioncapacity"  >
                                 <span class="text-danger size-7 e_waste_product_type"></span>
                        </div>
                         <div class="form-group mb-0  col-md-4">
                            <label>Mothly disposal of Waste Paper</label><span class="text-danger">*</span>
                            <input type="text" class="form-control " name="monthlydisposalwastepaper">
                            <span class="text-danger size-7 e_qty"></span>
                        </div>
                         <div class="form-group mb-0  col-md-4">
                            <label>One time disposal of Waste Paper</label><span class="text-danger">*</span>
                            <input type="text" class="form-control " name="disposalwastepaper">
                            <span class="text-danger size-7 e_qty"></span>
                        </div>
                        <div class="form-group mb-0  col-md-4">
                            <label>Detail of Plant Machinery</label><span class="text-danger">*</span>
                            <input type="text" class="form-control " name="plantmachinery"  >
                            <span class="text-danger size-7 e_qty"></span>
                            </div>
                        <div class="form-group mb-0  col-md-4">
                            <label>Process you are outsourcing on job work basis</label><span class="text-danger">*</span>
                            <input type="text" class="form-control " name="outsourcingjobwork"  >
                            <span class="text-danger size-7 e_qty"></span>
                            </div>
                        <div class="form-group mb-0  col-md-4">
                            <label>Monthly consumption of stitching wire</label><span class="text-danger">*</span>
                            <input type="text" class="form-control " name="stitchingwireconsumption"  >
                            <span class="text-danger size-7 e_qty"></span>
                            </div>
                        <div class="form-group mb-0  col-md-4">
                            <label>How many trucks yow own for supply?</label><span class="text-danger">*</span>
                            <input type="text" class="form-control " name="trucksown"  >
                            <span class="text-danger size-7 e_qty"></span>
                            </div>
                        <div class="form-group mb-0  col-md-4">
                            <label>How often you need technical assistance?</label><span class="text-danger">*</span>
                            <input type="text" class="form-control " name="technicalassistance"  >
                            <span class="text-danger size-7 e_qty"></span>
                            </div>
                        <div class="form-group mb-0  col-md-4">
                            <label>Other material used</label><span class="text-danger">*</span>
                            <input type="text" class="form-control " name="materialused"  >
                            <span class="text-danger size-7 e_qty"></span>
                         </div>
                      
                        <div class="form-group mb-0  col-md-4">
                                <label>Areas where your boxes are supplied?</label><span class="text-danger">*</span>
                                <input type="text" class="form-control" name="areasupplied" tag="1" id=""  >
                                <span class="text-danger size-7 e_buying_rate"></span>
                        </div>
                        <div class="form-group mb-0  col-md-4">
                            <label>How frequently machine repair service is required</label><span class="text-danger">*</span>
                            <input type="text" class="form-control " name="frequency_machine_service"  >
                            <span class="text-danger size-7 e_qty"></span>
                            </div>
                        <div class="form-group mb-0  col-md-4">
                            <label>Number of staff working in the premises</label><span class="text-danger">*</span>
                            <input type="text" class="form-control " name="staff_no"  >
                            <span class="text-danger size-7 e_qty"></span>
                            </div>
                        <div class="form-group mb-0  col-md-4">
                            <label>Any software owned for accounting purpose</label><span class="text-danger">*</span><br>
                            <input type="radio" class=" " name="accounting"   value="1"> Yes
                            <input type="radio" class=" " name="accounting"   value="0"> No
                            <span class="text-danger size-7 e_qty"></span>
                         </div>
                        
                        <div class="form-group mb-0 list_type_description col-md-4">
                           
                        </div>
                   </div>
            