                     <h4> Work profile For Bailer Registration</h4>
                    <div class="form-row">
                       
                         <div class="form-group mb-0 col-md-4">
                            <label>Monthly Conversion capcity of machine <noframes></noframes></label><span class="text-danger">*</span>
                            <input type="text" class="form-control list-product" name="mconverCapcity" id="mconverCapcity" tag="1" autocomplete="off" >
                            <div class="suggestionAra product"></div>
                            <span class="text-danger size-7 e_product_id"></span>
                        </div>

                        <div class="form-group mb-0  col-md-4">
                            <label>Conversion of waste paper</label><span class="text-danger">*</span>
                            <input type="text" class="form-control " name="convwastepaper"  >
                            <span class="text-danger size-7 e_qty"></span>
                        </div>
                        <div class="form-group mb-0  col-md-4">
                            <label>Number of machine</label><span class="text-danger">*</span>
                            <input type="text" class="form-control " name="machine_no"  >
                            <span class="text-danger size-7 e_qty"></span>
                        </div>
                         <div class="form-group mb-0  col-md-4">
                            <label>Type of machine</label><span class="text-danger">*</span>
                            <input type="text" class="form-control " name="machine_type"  >
                            <span class="text-danger size-7 e_qty"></span>
                        </div>
                         <div class="form-group mb-0  col-md-4">
                            <label> Weight (per bundle)</label><span class="text-danger">*</span>
                            <input type="text" class="form-control " name="bundleweight"  >
                            <span class="text-danger size-7 e_qty"></span>
                        </div>
                        <div class="form-group mb-0  col-md-4">
                            <label> Type of Waste Paper</label><span class="text-danger">*</span><br>
                            <input type="checkbox"  name="type_of_waste[]" value="White Paper" >  White Paper            
                            <strong> Qty</strong>
                              <input type="text"  name="wpqty[]"  ><br>
                              <input type="checkbox"  name="type_of_waste[]" value="Kraft Paper" >  Kraft Paper            
                              <strong>    Qty</strong>
                              <input type="text"  name="wpqty[]"  ><br>
                              <input type="checkbox"  name="type_of_waste[]" value="White Paper" > Other Paper           
                               <strong> Qty</strong>
                              <input type="text"  name="wpqty[]"  ><br>
                           
                        </div>
                        <div class="form-group mb-0 col-md-6">
                                <label>Quality White Waste Paper</label><span class="text-danger">*</span><br>  
                                <input type="checkbox"  name="type_of_waste[]" value=" Sacn " > Sacn  <br>   
                                <input type="checkbox"  name="type_of_waste[]" value=" Color" > Color  <br>
                                <input type="checkbox"  name="type_of_waste[]" value="Copy" > Copy   <br>         
                                <input type="checkbox"  name="type_of_waste[]" value="Record" > Record   <br>   
                                <input type="checkbox"  name="type_of_waste[]" value="Sorted Books" > Sorted Books <br>   
                                <input type="checkbox"  name="type_of_waste[]" value="White Cutting Waste 1st Brightness 80% Plus " >  White Cutting Waste 1st Brightness 80% Plus   <br>   
                                <input type="checkbox"  name="type_of_waste[]" value="White Pepsi" >  White Pepsi   <br>   
                                <input type="checkbox"  name="type_of_waste[]" value="White Board" >  White Board   <br>   
                                <input type="checkbox"  name="type_of_waste[]" value="Old Book" >  Old Book   <br>   
                        </div>
                         <div class="form-group mb-0 col-md-6">
                                <label>Quality Kraft Waste Paper</label><span class="text-danger">*</span><br>  
                                <input type="checkbox"  name="type_of_waste[]" value=" 100 % Corrugation 1st " > 100 % Corrugation 1st  <br>   
                                <input type="checkbox"  name="type_of_waste[]" value=" 90 % Corrugation 1st  , 10 % Corr 2nd" > 90 % Corrugation 1st  , 10 % Corr 2nd  <br>
                                <input type="checkbox"  name="type_of_waste[]" value="80 % Corrugation 1st  , 20 % Corr 2nd" > 80 % Corrugation 1st  , 20 % Corr 2nd   <br>         
                                <input type="checkbox"  name="type_of_waste[]" value="70 % Corrugation 1st  , 30 % Corr 2nd" > 70 % Corrugation 1st  , 30 % Corr 2nd   <br>   
                                <input type="checkbox"  name="type_of_waste[]" value="70 % Corrugation 1st  , 15-20 % Corr 2nd , Balance Qualities" > 70 % Corrugation 1st  , 15-20 % Corr 2nd , Balance Qualities  <br>   
                                <input type="checkbox"  name="type_of_waste[]" value="Grey Board Paper " >  Grey Board Paper   <br>   
                                <input type="checkbox"  name="type_of_waste[]" value="Mill Board Paper" >  Mill Board Paper   <br>   
                        </div>
                        <div class="form-group mb-0 col-md-4">
                                <label>Preferable areas to supply waste paper</label><span class="text-danger">*</span>
                                 <input type="text" class="form-control " name="pareasupplywastepaper"  >
                                 <span class="text-danger size-7 e_waste_product_type"></span>
                        </div>
                         <div class="form-group mb-0  col-md-4">
                            <label>Preferable mills to supply waste paper</label><span class="text-danger">*</span>
                            <input type="text" class="form-control " name="pmillsupplywastepaper">
                            <span class="text-danger size-7 e_qty"></span>
                        </div>
                         <div class="form-group mb-0  col-md-4">
                            <label>Number of owned trucks for collection</label><span class="text-danger">*</span>
                            <input type="text" class="form-control " name="trucks_no"  >
                            <span class="text-danger size-7 e_qty"></span>
                        </div>
                        <div class="form-group mb-0  col-md-4">
                            <label>Number of owned trucks for supply</label><span class="text-danger">*</span>
                            <input type="text" class="form-control " name="trucks_supply"  >
                            <span class="text-danger size-7 e_qty"></span>
                            </div>
                        <div class="form-group mb-0  col-md-4">
                            <label>Min. Qty. required for waste paper pickup</label><span class="text-danger">*</span>
                            <input type="text" class="form-control " name="minqty_wastepaper_pickup"  >
                            <span class="text-danger size-7 e_qty"></span>
                            </div>
                        <div class="form-group mb-0  col-md-4">
                            <label>Distance range for pickup of Waste Paper</label><span class="text-danger">*</span>
                            <input type="text" class="form-control " name="minqty_wastepaper_pickup"  >
                            <span class="text-danger size-7 e_qty"></span>
                            </div>
                        <div class="form-group mb-0  col-md-4">
                            <label>How frequently machine repair service is required</label><span class="text-danger">*</span>
                            <input type="text" class="form-control " name="frequency_machine_service"  >
                            <span class="text-danger size-7 e_qty"></span>
                            </div>
                        <div class="form-group mb-0  col-md-6">
                            <label>What material does your load back to your origin after unloading of waste paper in mill</label><span class="text-danger">*</span>
                            <input type="text" class="form-control " name="material"  >
                            <span class="text-danger size-7 e_qty"></span>
                            </div>
                        <div class="form-group mb-0  col-md-4">
                            <label>Number of staff working in the premises</label><span class="text-danger">*</span>
                            <input type="text" class="form-control " name="staff_no"  >
                            <span class="text-danger size-7 e_qty"></span>
                            </div>
                        <div class="form-group mb-0  col-md-4">
                            <label>Any software owned for accounting purpose</label><span class="text-danger">*</span><br>
                            <input type="radio" class=" " name="accounting"   value="1"> Yes
                            <input type="radio" class=" " name="accounting"   value="0"> No
                            <span class="text-danger size-7 e_qty"></span>
                         </div>
                      
                      
                        
                        <div class="form-group mb-0 list_type_description col-md-4">
                           
                        </div>
                   </div>
            