<!--                     <h4>  Work profile For Paper Mill Registration</h4>
                    <div class="form-row">
                        
                         <div class="form-group mb-0 col-md-4">
                            <label>Conversion capcity of machine <noframes></noframes></label><span class="text-danger">*</span>
                            <input type="text" class="form-control list-product" name="converCapcity" id="converCapcity" tag="1" autocomplete="off" >
                            <div class="suggestionAra product"></div>
                            <span class="text-danger size-7 e_product_id"></span>
                        </div>

                        <div class="form-group mb-0  col-md-4">
                            <label>Conversion of waste paper</label><span class="text-danger">*</span>
                            <input type="text" class="form-control " name="convwastepaper"  >
                            <span class="text-danger size-7 e_qty"></span>
                        </div>
                         <div class="form-group mb-0  col-md-4">
                            <label>Number of machine</label><span class="text-danger">*</span>
                            <input type="text" class="form-control " name="machine_no"  >
                            <span class="text-danger size-7 e_qty"></span>
                        </div>
                         <div class="form-group mb-0  col-md-4">
                            <label>Weight (per bundle)</label><span class="text-danger">*</span>
                            <input type="text" class="form-control " name="bundleweight"  >
                            <span class="text-danger size-7 e_qty"></span>
                        </div>
                        <div class="form-group mb-0 col-md-4">
                                <label>Preferable areas to supply waste paper</label><span class="text-danger">*</span>
                                 <input type="text" class="form-control " name="pareasupplywastepaper"  >
                                 <span class="text-danger size-7 e_waste_product_type"></span>
                        </div>
                         <div class="form-group mb-0  col-md-4">
                            <label>Preferable mills to supply waste paper</label><span class="text-danger">*</span>
                            <input type="text" class="form-control " name="pmillsupplywastepaper">
                            <span class="text-danger size-7 e_qty"></span>
                        </div>
                         <div class="form-group mb-0  col-md-4">
                            <label>Number of owned trucks for collection</label><span class="text-danger">*</span>
                            <input type="text" class="form-control " name="trucks_no"  >
                            <span class="text-danger size-7 e_qty"></span>
                        </div>
                        <div class="form-group mb-0  col-md-4">
                            <label>Number of owned trucks for supply</label><span class="text-danger">*</span>
                            <input type="text" class="form-control " name="trucks_supply"  >
                            <span class="text-danger size-7 e_qty"></span>
                            </div>
                        <div class="form-group mb-0  col-md-4">
                            <label>Min. Qty. required for waste paper pickup</label><span class="text-danger">*</span>
                            <input type="text" class="form-control " name="minqty_wastepaper_pickup"  >
                            <span class="text-danger size-7 e_qty"></span>
                            </div>
                        <div class="form-group mb-0  col-md-4">
                            <label>How frequently machine repair service is required</label><span class="text-danger">*</span>
                            <input type="text" class="form-control " name="frequency_machine_service"  >
                            <span class="text-danger size-7 e_qty"></span>
                            </div>
                        <div class="form-group mb-0  col-md-4">
                            <label>What material does your load back to your origin after unloading of waste paper in mill</label><span class="text-danger">*</span>
                            <input type="text" class="form-control " name="material"  >
                            <span class="text-danger size-7 e_qty"></span>
                            </div>
                        <div class="form-group mb-0  col-md-4">
                            <label>Number of staff working in the premises</label><span class="text-danger">*</span>
                            <input type="text" class="form-control " name="staff_no"  >
                            <span class="text-danger size-7 e_qty"></span>
                            </div>
                        <div class="form-group mb-0  col-md-4">
                            <label>Any software owned for accounting purpose</label><span class="text-danger">*</span>
                            <input type="text" class="form-control " name="software_owned"  >
                            <span class="text-danger size-7 e_qty"></span>
                         </div>
                      
                        <div class="form-group mb-0  col-md-4">
                                <label>Buying Rate</label><span class="text-danger">*</span>
                                <input type="text" class="form-control" name="buying_rate" tag="1" id="buying_rate"  >
                                <span class="text-danger size-7 e_buying_rate"></span>
                        </div>
                        
                        <div class="form-group mb-0 list_type_description col-md-4">
                           
                        </div>
                   </div>
             -->