<div class="container-fluid">

	<h2 class="text-center m-3"> Order Placed Successfully<br>
	  <a href="javascript:void(0)" class="btn btn-primary mb-2 <?=$redirect?>" >Continue</a></h2>
                  
</div>