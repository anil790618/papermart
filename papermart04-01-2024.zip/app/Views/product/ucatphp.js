     <tr>
                                            <td class="p-0">Sub Category</td>
                                            <td class="p-0"><input type="checkbox" value="sub_category"  name="product_specification[]" class="mr-3"> </td>
                                            <td class="p-0"><input type="checkbox" value="sub_category"  name="required[]" class="mr-3"> </td>
                                        </tr>
                                        <tr>
                                            <td class="p-0">Quality</td>
                                            <td class="p-0"><input type="checkbox" value="quality"  name="product_specification[]" class="mr-3"> </td>
                                            <td class="p-0"> <input type="checkbox" value="quality"  name="required[]" class="mr-3"> </td>
                                        </tr>
                                         <tr>
                                            <td class="p-0">Quantity Type</td>
                                            <td class="p-0"> <input type="checkbox" value="quantity_type"  name="product_specification[]" class="mr-3">  </td>
                                            <td class="p-0"><input type="checkbox" value="quantity_type"  name="required[]" class="mr-3"> </td>
                                        </tr>
                                         <tr>
                                            <td class="p-0">Quantity</td>
                                            <td class="p-0">   <input type="checkbox" value="quantity"  name="product_specification[]" class="mr-3"> </td>
                                            <td class="p-0"> <input type="checkbox" value="quantity"  name="required[]" class="mr-3"></td>
                                        </tr>
                                         <tr>
                                            <td class="p-0">Quantity UOM</td>
                                            <td class="p-0"> <input type="checkbox" value="quantity_uom"  name="product_specification[]" class="mr-3"> </td>
                                            <td class="p-0"><input type="checkbox" value="quantity_uom"  name="required[]" class="mr-3">  </td>
                                        </tr>
                                         <tr>
                                            <td class="p-0">Product Form</td>
                                            <td class="p-0"><input type="checkbox" value="product_form"  name="product_specification[]" class="mr-3">  </td>
                                            <td class="p-0"> <input type="checkbox" value="quantity_uom"  name="required[]" class="mr-3"> </td>
                                        </tr>
                                         <tr>
                                            <td class="p-0">Rate</td>
                                            <td class="p-0"><input type="checkbox" value="rate"  name="product_specification[]" class="mr-3">  </td>
                                            <td class="p-0"> <input type="checkbox" value="quantity_uom"  name="required[]" class="mr-3"> </td>
                                        </tr>
                                         <tr>
                                            <td class="p-0">Mill Name</td>
                                            <td class="p-0"> <input type="checkbox" value="mill_name"  name="product_specification[]" class="mr-3"> </td>
                                            <td class="p-0"> <input type="checkbox" value="quantity_uom"  name="required[]" class="mr-3"> </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                           <div class="col-1">
                           </div>
                          <div class="col-5">
                                <table class="table table-responsive-sm  size-7">
                                    <thead >
                                        <th class="p-0">Specification</th>
                                        <th class="p-0">Category Includes</th>
                                        <th class="p-0">Required</th>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td class="p-0">BF</td>
                                            <td class="p-0"> <input type="checkbox" value="bf"  name="product_specification[]" class="mr-3">  </td>
                                            <td class="p-0"> <input type="checkbox" value="bf"  name="required[]" class="mr-3"> </td>
                                        </tr>
                                        <tr>
                                            <td class="p-0">Type</td>
                                            <td class="p-0"><input type="checkbox" value="type"  name="product_specification[]" class="mr-3"> </td>
                                            <td class="p-0"><input type="checkbox" value="type"  name="required[]" class="mr-3">  </td>
                                        </tr>
                                         <tr>
                                            <td class="p-0">Shade</td>
                                            <td class="p-0"><input type="checkbox" value="shade"  name="product_specification[]" class="mr-3">  </td>
                                            <td class="p-0"><input type="checkbox" value="shade"  name="required[]" class="mr-3"> </td>
                                        </tr>
                                         <tr>
                                            <td class="p-0">GSM</td>
                                            <td class="p-0"> <input type="checkbox" value="gsm"  name="product_specification[]" class="mr-3"> </td>
                                            <td class="p-0"> <input type="checkbox" value="gsm"  name="required[]" class="mr-3"></td>
                                        </tr>
                                         <tr>
                                            <td class="p-0">Size</td>
                                            <td class="p-0"><input type="checkbox" value="size"  name="product_specification[]" class="mr-3"> </td>
                                            <td class="p-0"><input type="checkbox" value="size"  name="required[]" class="mr-3">  </td>
                                        </tr>
                                         <tr>
                                            <td class="p-0">Size UOM</td>
                                            <td class="p-0"> <input type="checkbox" value="size_uom"  name="product_specification[]" class="mr-3"> </td>
                                            <td class="p-0"> <input type="checkbox" value="size_uom"  name="required[]" class="mr-3"> </td>
                                        </tr>
                                         <tr>
                                            <td class="p-0">Pulp</td>
                                            <td class="p-0"> <input type="checkbox" value="pulp"  name="product_specification[]" class="mr-3"> </td>
                                            <td class="p-0"> <input type="checkbox" value="pulp"  name="required[]" class="mr-3"> </td>
                                        </tr>
                                         <tr>
                                            <td class="p-0">Brightness</td>
                                            <td class="p-0">  <input type="checkbox" value="brightness"  name="product_specification[]" class="mr-3">  </td>
                                            <td class="p-0"> <input type="checkbox" value="brightness"  name="required[]" class="mr-3"> </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                           
                        </div>