

<div class="container-fluid">
	
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title m-2">Not Registered</h4>
                   
                </div>
                <div class="card-body">

                 <h5 class="text-center"> <?=$error;?></h5>
                   
                </div>
            </div>
        </div>
    </div>
</div>

